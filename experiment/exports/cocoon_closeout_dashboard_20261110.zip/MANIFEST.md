# 离线结案交付包索引

共 29 个文件；每项附 SHA-256。

| 文件 | 字节 | SHA-256 |
|---|---:|---|
| `dashboard.html` | 1870010 | `46c6a0dc37fc79e0fc49293c05040ccb9a3886d35b5d32e7e76d8e194babec58` |
| `dashboard_data.json` | 1856479 | `6437e3a51db9df2f81f9a0426aa883548d372ef6ff507bb73dfe0158528efb68` |
| `verification.json` | 5949 | `5397d08ef87764ad015a08f8b3d327c2a4589dcab1ccec40db183e8a784ec1af` |
| `REPORT_step37_20261110.md` | 12786 | `3e1292622ce18b9737a0672efe7bb986f7dbe817c2d40588b04d6ec5bbbeac25` |
| `REPORT_step38_20261110.md` | 13140 | `b96bc7fbc8c571a8f881fbfb85629be53e9acfd8658f18921fabd9e3053d8451` |
| `live_cross_topic_20261111/six_round_live_extractive_pairs.json` | 34289 | `58f97ac380e8bcc3b82927aab70c6e57125f64678867edf653d43e8fdb9d73d3` |
| `live_micro_pilot_20261111/topic01_live_micro_pilot.json` | 105820 | `166aea62aa48ccdef72250f18a2490b20c0308fc1f73f83e9754900303529dc0` |
| `live_micro_pilot_20261111/topic02_live_micro_pilot.json` | 109059 | `45e5da1f23ace5afefad54186e8026ac354143c200f6b96182763e0ceee736ec` |
| `live_micro_pilot_20261111/topic03_live_micro_pilot.json` | 104354 | `654aaad5e70b6323d6e9d883a034bb2ee9a354423047d119946e66ec9ede2157` |
| `live_micro_pilot_20261111/three_topic_live_micro_pilot_matrix.json` | 9761 | `8469f7dd5dc206ae4583725ddd3c7269ed96b36a8260667ce00ebc7710866d2c` |
| `live_micro_pilot_20261111/closed_world_synth01_live_pilot.json` | 197980 | `a6d916ea9419ff06108cfa28bd40e0b81eb2d399281a5f6f7b20dc4c5afb2dfe` |
| `FINAL_PROJECT_REPORT_20261114.md` | 23441 | `6241ebf1851f86ef406e2548612cba3ed5ed0b8e5884ab2daed12d1686d2d382` |
| `DEFENSE_PRESENTATION_GUIDE_20261114.md` | 20786 | `98e8bb7a1c3db64dd0d260a12e4c431f11c03d5cea3c1164473a67f9421751a1` |
| `scheme_a_merged_verified.json` | 344493 | `a633b9797c8a8fd331bcea486109e96883db5863fdbaff8cbb04dfde7edbc08b` |
| `cross_topic_20261108/review.html` | 398347 | `796dd3a24e0f3a78a6eb403ee0fa34f368da897c12162597017205476bb03641` |
| `PROGRESS.md` | 132428 | `2adcf6d73191dd8bb3f7617738dc243c524651c1790155b91bab38e206dbbf5f` |
| `experiment/review/ai_assisted_review_20261110/REPORT_step36_20261110.md` | 15794 | `2d52bfd259ed84c2e83778e183e063329f114fa53433a25b04ad84278a14544f` |
| `experiment/review/cross_topic_20261108/REPORT_step28_20261108.md` | 6517 | `d7c42ddd6a238ab8f6439637d38754831293f056873d7f5a079b733edb1dc9f4` |
| `experiment/review/cross_topic_20261108/REPORT_step29_20261108.md` | 11958 | `95c7b9c108d0ee2f8415003b89fac82808012bc1970b9a6964bd162eefe092bb` |
| `experiment/review/live_cross_topic_20261111/REPORT_step39_20261111.md` | 10817 | `12fa61051a2b3dd937bb0052bd77405c029b0f1e515eb96fdc0af4bc9fb6bc57` |
| `experiment/review/live_micro_pilot_20261111/REPORT_step40_20261111.md` | 14005 | `e645b5111aa9db619b7336513c0ce834210e6b86b5b5a07624e608decc8799b1` |
| `experiment/review/live_micro_pilot_20261111/REPORT_step41_20261113.md` | 13645 | `004629257f7f68d1949b823d6050c63bd8b6957dd67558bef905c10ca5aa48f7` |
| `experiment/review/live_micro_pilot_20261111/REPORT_step42_20261114.md` | 13337 | `4b2a4b365ef90f8e7080c6f2286f560129c493b2e06f179dfb3f9a921ddc44b3` |
| `experiment/review/measurement_20261108/REPORT_step30_20261108.md` | 12795 | `b15f43b7db227af50a51dd395f853ebae37e1d4f96602dd0383b02f301247990` |
| `experiment/review/measurement_20261108/REPORT_step31_20261108.md` | 12710 | `b7a08c7bd2e5a1ff408782fb071e75834c42e5247a38893ee3498d86b4710c17` |
| `experiment/review/measurement_20261108/REPORT_step32_20261108.md` | 14365 | `3cfd31d20803d7ffa2b917403b2cc1a53f861890bbf525024b63bebfccb85326` |
| `experiment/review/pilot_materials_20261109/REPORT_step33_20261109.md` | 15005 | `63139fda4c9d825a825c521fa30b76fee918df992f3a5b94b8d22ee09819f242` |
| `experiment/review/pilot_materials_20261109/REPORT_step34_20261109.md` | 14324 | `a2e6207fcccb72801e514f316bb7c57ca740b4b1efb80b838365b79419ba5810` |
| `experiment/review/pilot_materials_20261109/REPORT_step35_20261109.md` | 17293 | `49ba816a2fffeae8a4e1c7a501e7058b64238efae5541d1090fc05e996804cfd` |

## 说明

- 仅含白名单产物；不含原始网页全文、取证底稿或任何密钥。
- `dashboard.html` 单文件自包含，本地打开即可；无外部 CDN 请求。
- 看板为离线系统预演与方案A核验，不是真实模型认知实验结果。
- 步骤38已修复时间轴胶囊行内块撕裂与筛选区布局缺陷，并为全部视图补齐表格横向滚动保护、网络网格与单一 sticky 顶栏。
- 步骤39 六轮真实组织侧与原句摘录配对清单随包提供（含 Run ID、Token 与费用）。
- `PROGRESS.md` 为项目进度索引；步骤28–42 的 Markdown 汇报原样收录。
- 步骤41 三议题真实端到端实证清单（TOPIC_01/02/03）与三议题汇总矩阵随包提供（每议题 n=2×3，仅描述性对比）。
- 步骤40 TOPIC_01 真实微型实证清单随包提供（n=2×3 机制演示，非统计推断；含被取代运行与中断持有预留披露）。
- 步骤42 §5.4 封闭虚构情境 TOPIC_SYNTH_01（星澜市）真实实证清单随包提供：全部条目标 synthetic，不作为现实世界效果证据；另附总结案报告与五人答辩攻略。
